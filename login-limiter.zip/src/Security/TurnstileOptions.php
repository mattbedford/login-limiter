<?php declare(strict_types=1);

namespace LAL\Security;

final class TurnstileOptions
{
    public function __construct(
        public string $siteKey,
        public string $secretKey,
        public string $theme = 'auto',   // 'auto' | 'light' | 'dark'
        public string $size  = 'normal'  // 'normal' | 'compact' | 'flexible'
    ) {}
}